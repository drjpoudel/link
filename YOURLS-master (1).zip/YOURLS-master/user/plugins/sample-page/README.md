Sample Page
===========
This is a sample plugin, for illustration purpose.
Don't modify this plugin. Instead, copy its folder
and modify your own copy. This way, your code won't
be overwritten when you upgrade YOURLS.